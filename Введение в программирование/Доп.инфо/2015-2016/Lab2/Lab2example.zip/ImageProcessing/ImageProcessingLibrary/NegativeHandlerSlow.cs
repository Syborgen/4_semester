﻿using System.Collections.Generic;
using System.Drawing;

namespace ImageProcessingLibrary
{
    public class NegativeHandlerSlow : IImageHandler
    {

        private const string HANDLER_NAME = "Negative slow handler";

        private Bitmap bitmap;


        public string HandlerName 
        {
            get { return HANDLER_NAME; }            
        }


        public void init(SortedList<string, object> parameters)
        {
            
        }

        
        public Bitmap Source 
        {
            set { bitmap = value; } 
        }

        
        public Bitmap Result 
        {
            get { return bitmap; }
        }

        //Запуск обработки
        public void startHandle(ProgressDelegate progressDelegate)
        {

            Bitmap result = new Bitmap(bitmap.Width, bitmap.Height);

            for (int i = 0; i < bitmap.Width; i++)
            {

                for (int j = 0; j < bitmap.Height; j++)
                {

                    Color oldColor = bitmap.GetPixel(i, j);

                    Color newColor = Color.FromArgb(255-oldColor.R, 255-oldColor.G, 255-oldColor.B);

                    result.SetPixel(i, j, newColor);
                }

                progressDelegate((double)(i + 1) / bitmap.Width * 100);

            }

            this.bitmap = result;

        }

    }
}
