﻿using System;
using ImageProcessingLibrary;
using System.Drawing;
using System.Drawing.Imaging;
using System.Diagnostics;

namespace ImageProcessingTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();

            Stopwatch sw = new Stopwatch();

            Bitmap src = new Bitmap("example.jpg");

            IImageHandler handler = new NegativeHandlerSlow();

            Console.WriteLine(handler.HandlerName);

            handler.Source = src;

            sw.Reset();

            sw.Start();

            handler.startHandle(new ProgressDelegate(showProgress));            

            sw.Stop();

            long time1 = sw.ElapsedMilliseconds;

            handler.Result.Save("out1.bmp", ImageFormat.Bmp);

            Console.WriteLine("\nPress any key");

            Console.ReadLine();

            Console.Clear();

            sw.Reset();

            sw.Start();

            handler = new NegativeHandlerFast();

            Console.WriteLine(handler.HandlerName);

            handler.Source = src;

            handler.startHandle(new ProgressDelegate(showProgress));            

            sw.Stop();

            long time2 = sw.ElapsedMilliseconds;

            handler.Result.Save("out2.bmp", ImageFormat.Bmp);            

            Console.WriteLine("\nSlow time = {0:D}, Fast time = {1:D}", time1, time2);

            Console.ReadLine();
        
        }

        static void showProgress(double progress)
        {

            Console.SetCursorPosition(0, 1);

            Console.Write("{0,4:F}%", progress);

        }
    }
}



        

