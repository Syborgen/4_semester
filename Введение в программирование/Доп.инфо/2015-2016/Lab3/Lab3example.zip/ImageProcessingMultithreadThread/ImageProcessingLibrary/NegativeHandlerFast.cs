﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace ImageProcessingLibrary
{
    public class NegativeHandlerFast:IImageHandler
    {
        private const string HANDLER_NAME = "Negative fast handler";

        private Bitmap bitmap;

        private long time;

        public long Time
        {

            get { return time;}

        }

        public string HandlerName 
        {
            get { return HANDLER_NAME; }            
        }


        public void init(SortedList<string, object> parameters)
        {
            
        }

        
        public Bitmap Source 
        {
            set { bitmap = value; } 
        }

        
        public Bitmap Result 
        {
            get { return bitmap; }
        }


        //Запуск обработки для пула
        public void startHandle(object progressDelegate)
        {

            startHandle(progressDelegate as ProgressDelegate);

        }

        //Запуск обработки
        public void startHandle(ProgressDelegate progressDelegate)
        {

            Stopwatch sw = new Stopwatch();

            sw.Start();

            Bitmap result = new Bitmap(bitmap);

            Rectangle rect = new Rectangle(0, 0, result.Width, result.Height);

            BitmapData bitmapData = result.LockBits(rect, ImageLockMode.ReadWrite, result.PixelFormat);

            IntPtr ptr = bitmapData.Scan0;

            int bytes = bitmapData.Stride * result.Height;

            byte[] rgbValues = new byte[bytes];


            Marshal.Copy(ptr, rgbValues, 0, bytes);


            for (int i = 0; i < rgbValues.Length; i++)
            {

                if ((i + 1) % 4 == 0) continue;

                rgbValues[i] = (byte)(255 - rgbValues[i]);

                if (i % bitmap.Width == 0)
                {
                    progressDelegate((double)(i + 1) / rgbValues.Length * 100);
                }

            }



            Marshal.Copy(rgbValues, 0, ptr, bytes);

            result.UnlockBits(bitmapData);

            this.bitmap= result;

            sw.Stop();

            time = sw.ElapsedMilliseconds;

        }


    }
}
