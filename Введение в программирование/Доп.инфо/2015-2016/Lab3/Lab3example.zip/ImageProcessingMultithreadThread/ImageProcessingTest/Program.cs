﻿using System;
using ImageProcessingLibrary;
using System.Drawing;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Collections.Generic;
using System.Threading;

namespace ImageProcessingTest
{
    class Program
    {
        static void Main(string[] args)
        {
            const int NUM_OF_THREADS = 2;

            object locker = new object();

            List<NegativeHandlerFast> handlers = new List<NegativeHandlerFast>();

            List<Thread> threads = new List<Thread>();

            List<Progress> progresses = new List<Progress>();


            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                NegativeHandlerFast handler = new NegativeHandlerFast();

                handler.Source = new Bitmap(args[i]);

                handlers.Add(handler);

                Progress progress = new Progress(i,locker);                

                progresses.Add(progress);

            }


            

            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                NegativeHandlerFast handler = handlers[i];

                Progress progress = progresses[i];

                ProgressDelegate progressd = new ProgressDelegate(progress.showProgress);

                threads.Add(new Thread(() => handler.startHandle(progressd)));

            }

            Console.Clear();

            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                threads[i].Start();

            }


            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                threads[i].Join();

            }


            Console.Clear();

            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                Console.WriteLine("Image " + i + " size = " + handlers[i].Result.Width * handlers[i].Result.Height + " Time = " + handlers[i].Time);

            }

            for (int i = 0; i < NUM_OF_THREADS; i++)
            {

                handlers[i].Result.Save("out"+args[i],System.Drawing.Imaging.ImageFormat.Jpeg);

            }
            
            
            Console.ReadLine();
        
        }

        
     
    }


    class Progress
    {

        private object locker;

        private int num;

        public Progress(int num, object locker)
        {

            this.num = num;

            this.locker = locker;

        }


        public void showProgress(double progress)
        {

            lock (locker)
            {

                Console.SetCursorPosition(0, num);

                Console.Write("Thread " + num + " {0,4:F}%", progress);
            }

        }

    }
}



        

