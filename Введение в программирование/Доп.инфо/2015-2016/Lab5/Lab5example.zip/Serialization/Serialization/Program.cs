﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.ComponentModel;
using System.Drawing;

namespace Serialization
{
    [Serializable]
    public class Example
    {
        [XmlAttribute]
        public int ip;

        public string s;

        [XmlIgnore]
        public string ignore;

        [XmlIgnore]
        public Bitmap bitmap;
        
        int[] array;

        [XmlArray]
        [XmlArrayItem("v")]
        public int[] XMLArray
        {
            get { return array; }
            set { array = value; }
        }

        //Сериализация и десериализация картинки в виде массива байтов в XML
        [XmlElement]
        public byte[] XMLImage
        {
            get
            {
                MemoryStream mstream = new MemoryStream();
                bitmap.Save(mstream, System.Drawing.Imaging.ImageFormat.Png);
                byte[] ba = mstream.ToArray();
                mstream.Close();
                return ba;
            }
            set
            {
                bitmap = new Bitmap(new MemoryStream(value));
            }
        }

        public Example()
        {
            ignore = "default value";
            array = new int[10];
            for(int i=0; i<array.Length; i++)
                array[i] = i;
        }

        public void Print(string bitmapName="")
        {
            Console.WriteLine("ip = {0}", ip);
            Console.WriteLine("s = {0}", s);
            Console.WriteLine("ignore = {0}", ignore);

            Console.Write("Array:");
            for (int i = 0; i < array.Length; i++)
                Console.Write(" {0}", array[i]);
            Console.WriteLine();

            if (bitmapName != "")
            {
                bitmap.Save(bitmapName);
                Console.WriteLine("Bitmap uis saved to {0}", bitmapName);
            }
        }
    }

    class Program
    {
        static void Serialize_XmlSerializer(Example obj, string fileName)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create);
            XmlSerializer x = new XmlSerializer(obj.GetType());
            x.Serialize(fs, obj);
            fs.Close();
        }

        static Example Deserialize_XmlSerializer(string fileName)
        {
            FileStream fs = new FileStream(fileName, FileMode.Open);
            XmlSerializer x = new XmlSerializer(typeof(Example));
            Example obj = (Example)x.Deserialize(fs);
            fs.Close();
            return obj;
        }

        static void Serialize_XmlWriter(Example obj, string fileName)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            XmlWriter writer = XmlWriter.Create(fileName, settings);

            writer.WriteStartDocument();
            writer.WriteStartElement("Example");

            //writer.WriteElementString("ip", obj.ip.ToString());
            writer.WriteAttributeString("ip", obj.ip.ToString());

            writer.WriteElementString("s", obj.s);

            writer.WriteStartElement("XMLArray");
            for (int i = 0; i < obj.XMLArray.Length; i++)
            {
                writer.WriteElementString("v", obj.XMLArray[i].ToString());
            }
            writer.WriteEndElement();

            writer.WriteStartElement("XMLImage");
            var buf = obj.XMLImage;
            writer.WriteBase64(buf, 0, buf.Length);
            writer.WriteEndElement();

            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
        }

        static Example Deserialize_XmlReader(string fileName)
        {
            Example obj = new Example();
            XmlReader reader = XmlReader.Create(fileName);
            List<int> intList = new List<int>();

            reader.Read();
            for(;;)
            {
                XmlNodeType type = reader.NodeType;
                if (type == XmlNodeType.Element)
                {
                    switch (reader.Name)
                    {
                        case "Example":
                            reader.MoveToAttribute("ip");
                            obj.ip = reader.ReadContentAsInt();
                            break;
                        case "s":
                            obj.s = reader.ReadElementContentAsString();
                            break;
                        case "v":
                            intList.Add(reader.ReadElementContentAsInt());
                            break;
                        case "XMLImage":
                            {
                                byte[] buf = new byte[1000];
                                int readBytes;

                                Stream memStream = new MemoryStream();
                                BinaryWriter bw = new BinaryWriter(memStream);
                                while ((readBytes = reader.ReadElementContentAsBase64(buf, 0, 1000)) > 0)
                                {
                                    bw.Write(buf, 0, readBytes);
                                }
                                obj.bitmap = new Bitmap(memStream);
                            }
                            break;
                        default:
                            reader.Read();
                            break;
                    }
                }
                else if (reader.NodeType == XmlNodeType.EndElement)
                {
                    switch (reader.Name)
                    {
                        case "XMLArray":
                            obj.XMLArray = intList.ToArray();
                            break;
                    }
                    if(!reader.Read() )
                        break;
                }
                else
                {
                    if (!reader.Read())
                        break;
                }
            }

            reader.Close();

            return obj;
        }

        static void Main(string[] args)
        {
            // Create example
            Example src = new Example();
            src.ip = 13;
            src.s = "Hello World!";            
            src.ignore = "Bye World!";
            src.bitmap = new Bitmap("example.png");
            Console.WriteLine("Source object:");
            src.Print();
            Console.WriteLine();

            // Serialize example
            Serialize_XmlSerializer(src, "example1.xml");
            Serialize_XmlWriter(src, "example2.xml");

            // Deserialize example
            Example dst = Deserialize_XmlSerializer("example1.xml");
            Console.WriteLine("After deserialization with XmlSerializer:");
            dst.Print("out1.bmp");
            Console.WriteLine();

            dst = Deserialize_XmlReader("example2.xml");
            Console.WriteLine("After deserialization with XmlReader:");
            dst.Print("out2.bmp");
            Console.WriteLine();

            // Finish program
            Console.Write("Press any key...");
            Console.ReadKey();
        }
    }
}
